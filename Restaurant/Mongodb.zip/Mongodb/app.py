from flask import Flask, render_template, request
import folium
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient(port=27017)
db = client.pattukkottai

app = Flask(__name__)
@app.route('/')
def home():
    return render_template("index.html")

@app.route('/map', methods=["GET", "POST"])
def map():
    my_map = folium.Map(location=[10.4232,79.3200], zoom_start=10,min_zoom=1)
    
    points = list(db.locations.find())  
    
    for point in points:
        folium.Marker(location=[point['Lon'],point['Lat']], popup=point['Name']).add_to(my_map)
    
    map_html = "templates/map.html"
    my_map.save(map_html)
    return render_template('map.html', map_html=map_html)

if __name__ == '__main__':
    app.run(debug=True)
